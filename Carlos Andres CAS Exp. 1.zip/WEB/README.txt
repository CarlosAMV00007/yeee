For seeing the webpage, you have to click in the file that says "Carlos' Surf Blog"
Open it with Chrome or any other search engine